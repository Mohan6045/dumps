package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.Wrapperclass;

public class Home extends Wrapperclass{
	
	WebDriver driver;
	
	
	By logo=By.xpath("//header[@class='new-header desktop sticky-enable']//child::img[@src='/assets/images/img/logo.png']");
	
	public Home(WebDriver driver)
	{
		this.driver=driver;
		
	}

	public void logoClick()
	{
		clickOnElement(driver,logo);
	}
	
	
}
