package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Pages_download {
	WebDriver dr;
	
	public Pages_download(WebDriver dr) {
		
		this.dr=dr;
	}

	
	public void page() throws InterruptedException {
		
		dr.findElement(By.xpath("//*[@id=\"navbar\"]/a[1]")).click();
		Thread.sleep(300);
	}
	public void second() throws InterruptedException {
		dr.findElement(By.xpath("/html/body/div[2]/div[2]/p/a[2]")).click();
	Thread.sleep(3000);
		
	}
	
	public void fin() throws InterruptedException {
		this.page();
		this.second();
	}
}
