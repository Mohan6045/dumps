package Wrapper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import TestCases.NewTest1;

public class Launching extends NewTest1 {
	WebDriver dr;
	public WebDriver launch() {
		
		System.setProperty("WebDriver.chrome.Driver","chromedriver.exe");
		 dr=new ChromeDriver(options);
		dr.get("https://www.selenium.dev/");
		dr.manage().window().maximize();
		return dr;
	}

}
