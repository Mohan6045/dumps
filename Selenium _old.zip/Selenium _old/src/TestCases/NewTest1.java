package TestCases;

import org.testng.annotations.Test;

import Pages.Pages_download;
import Wrapper.Launching;

import org.testng.annotations.BeforeClass;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class NewTest1{
	
	static WebDriver dr;
	protected ChromeOptions options;
	 String downloadPath ;
	
	@Test(priority=1)
	  public void beforeClass() {
		
		System.setProperty("WebDriver.chrome.Driver","chromedriver.exe");
		 dr=new ChromeDriver(options);
		dr.get("https://www.selenium.dev/");
		dr.manage().window().maximize();
		
		
	  }
	
  @Test(priority=0)
  public void f() throws InterruptedException {
	  
	 
	  downloadPath = System.getProperty("user.dir") + File.separator + "downloads";
		System.out.println(downloadPath);

		// setting download path directory
		Map<String, String> prefs = new HashMap<String, String>();
		prefs.put("download.default_directory", downloadPath);

	 options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		
		
		
	  
  }
  

  @Test(priority=2)
  public void afterClass() throws InterruptedException {
	  Pages_download pag=new Pages_download(dr);
	  pag.fin();
	  Thread.sleep(8000);
	  File f= new File(downloadPath+"\\IEDriverServer_x64_3.150.1.zip");
  boolean b=f.exists();
  if(b==true) {
	  Assert.assertTrue(b,"meet requirements");
	  System.out.println("Meeting requirements");
  }
  else
  {
	  Assert.assertTrue(b,"Dont meet requirements");
	  System.out.println("Dont not");
  }
	  
	 dr.close();
  }

}
