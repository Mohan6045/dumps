package utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Library {
	static WebDriver dr;
	WebElement wb1;

	public static WebDriver Launch_browser(String browser,String url)
	{
		//String ch1="C:\\Users\\BLTuser.BLT0189\\eclipse-workspace\\CTS_maven_125\\src\\test\\resources\\DRIVER"
		
		switch(browser)
		{
		case "CHROME":
			System.setProperty("webdriver.chrome.driver","chromedriver.exe");
			dr=new ChromeDriver();
		break;
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver","geckodriver.exe");
			dr=new FirefoxDriver();
		break;
			
		}
		
		dr.get(url);
		
		
		return dr;
	}
	
	
	public WebElement WaitForElement(By locator,int timeout)
	{
		
		try
		{
		WebDriverWait WDW= new WebDriverWait(dr,timeout);
		 wb1=WDW.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			System.out.println("no element found");
					return null;
		}
		
		
	}
	
	
	public WebElement WaitForClickable(By locator,int timeout)
	{
		
		try
		{
		WebDriverWait WDW= new WebDriverWait(dr,timeout);
		 wb1=WDW.until(ExpectedConditions.visibilityOfElementLocated(locator));
		 return wb1;
		}
		catch (Exception e)
		{
			System.out.println("no element found");
			return null;
		}
		
	}

}
