package general;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class NewTest1223 {
	
	@Test
	public void phpTest() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//navigate to selenium.dev site
		driver.get("https://www.phptravels.net/");
		
		driver.findElement(By.xpath("//a[@data-name='flights']")).click();
		Actions actions=new Actions(driver);
		
		//From
		driver.findElement(By.xpath("//span[text()='NYC']")).click();
		actions.pause(1000).sendKeys("los").pause(5000).build().perform();
		driver.findElement(By.xpath("//div[contains(text(),'Lagos')]")).click();
		
		//To 
		driver.findElement(By.xpath("//span[text()='MIA']")).click();
		actions.pause(1000).sendKeys("arm").pause(5000).build().perform();
		driver.findElement(By.xpath("//div[contains(text(),'idale (ARM)')]")).click();
		
		WebElement dateEle= driver.findElement(By.id("FlightsDateStart"));
		JavascriptExecutor js =(JavascriptExecutor) driver;
		js.executeScript("arguments[0].value='2020-03-20'", dateEle);
		
		int adultCount=2;
		for(int i=1;i<=adultCount;i++)
		{
			driver.findElement(By.xpath("(//button[text()='+'])[3]")).click();
		}
		Thread.sleep(2000);
		int childCount=3;
		for(int i=1;i<=childCount;i++)
		{
			driver.findElement(By.xpath("(//button[text()='+'])[4]")).click();
		}
		Thread.sleep(2000);
		int infantCount=3;
		for(int i=1;i<=infantCount;i++)
		{
			driver.findElement(By.xpath("(//button[text()='+'])[5]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[contains(text(),'Search')])[2]")).click();
	}

}
