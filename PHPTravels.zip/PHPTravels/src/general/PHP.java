package general;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PHP {
	//   /html/body/div[2]/div[1]/div[1]/div[3]/div/div/div/div/div/div/div[1]/div/div/form/div/div/div[1]/div/div[2]/div/div/div/input

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.phptravels.net/home");     //    //div[@class='dropdown dropdown-currency']
		dr.manage().window().maximize();
		
		dr.findElement(By.xpath("//div[@class='dropdown dropdown-currency']")).click();
		dr.findElement(By.xpath("//a[@data-code='11']")).click();
		Thread.sleep(2000);
		dr.findElement(By.xpath("//a[@data-name='flights']")).click();
		dr.findElement(By.xpath("//*[@id=\"s2id_location_from\"]")).click();
		WebElement r=dr.findElement(By.xpath("/html/body/div[2]/div[1]/div[1]/div[3]/div/div/div/div/div/div/div[2]/div/div/form/div/div[3]/div[1]/div/div[1]/div/div[2]/div/a"));
		r.sendKeys("Los Angeles");
		Thread.sleep(2000);
		dr.findElement(By.xpath("/html/body/div[6]/ul/li[3]")).click();
		dr.findElement(By.xpath("//*[@id=\"s2id_location_to\"]/a")).click();
		dr.findElement(By.xpath("/html/body/div[7]/div/input")).sendKeys("Dallas");
		Thread.sleep(2000);
		dr.findElement(By.xpath("/html/body/div[7]/ul/li[4]")).click();
		
		

	}

}
