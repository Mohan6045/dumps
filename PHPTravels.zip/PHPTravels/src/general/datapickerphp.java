package general;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class datapickerphp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.phptravels.net/home");     //    //div[@class='dropdown dropdown-currency']
		dr.manage().window().maximize();
		
		//String cur_mn=
		dr.findElement(By.xpath("//a[@data-name='flights']")).click();
				dr.findElement(By.xpath("//*[@id=\"FlightsDateStart\"]")).click();
			String s=	dr.findElement(By.xpath("//*[@id=\"datepickers-container\"]/div[8]/nav/div[2]")).getText();
			System.out.println(s);
			
			//   date=  /html/body/div[3]/div[8]/div/div[2]/div
			
	}

}
