package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utilities.Library;

public class FROMTO extends Library {

	WebDriver dr;
	Library L;
	Actions a;

	public FROMTO(WebDriver dr)
	{
		this.dr=dr;
	 a=new Actions(dr);
	
	}
	
	public void Selcetcurrency()
	{
		dr.findElement(By.xpath("//div[@class='dropdown dropdown-currency']")).click();
		dr.findElement(By.xpath("//a[@data-code='11']")).click();
	}
	
	
	public void selectflights()
	{
		dr.findElement(By.xpath("//a[@data-name='flights']")).click();
	}
	public void From() throws InterruptedException
	
	{
		Thread.sleep(2000);
		dr.findElement(By.xpath("//span[text()='NYC']")).click();
		  a.pause(1000).sendKeys("LAX").pause(1000).build().perform();
		  dr.findElement(By.xpath("//div[contains(text(),'Los Angeles')] ")).click();
	}
	public void To() throws InterruptedException
	{
		Thread.sleep(2000);
		dr.findElement(By.xpath("//span[text()='MIA']")).click();
		  a.pause(1000).sendKeys("DFW").pause(1000).build().perform();
		  dr.findElement(By.xpath("//div[contains(text(),'Dallas')]")).click();
	}
	
	public void Selectdate() throws InterruptedException {
		Thread.sleep(2000);
		WebElement we=dr.findElement(By.id("FlightsDateStart"));
		  JavascriptExecutor js=(JavascriptExecutor)dr;
		  js.executeScript("arguments[0].value='2020-03-16'",we);
	}
	
	
	public void serch() throws InterruptedException

	{
		Thread.sleep(2000);
		dr.findElement(By.xpath("//div[@class='col-xs-12 col-md-1']//child::button")).click();
	}
	public void FROMTOSelect() throws InterruptedException
	{
		this.Selcetcurrency();
		this.selectflights();
		this.From();
		this.To();
		this.Selectdate();
		this.serch();
	}

}
