package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class price {
	WebDriver dr;
	
	public price(WebDriver dr)
	{
		this.dr=dr;
	}
	


	public int getprice() {

		  String s=dr.findElement(By.xpath("//ul[@id='LIST']//child::li[1]//following::strong[2]")).getText();
		  String s1=s.substring(4);
		  int n=Integer.parseInt(s1);
		  return n;
		
	}

}
