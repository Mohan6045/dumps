package SaucetestNG;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.FROMTO;
import Pages.price;
import utilities.Library;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;


public class Demo_Sauce_testng {
	
	 static WebDriver dr;
	 
	 @BeforeClass
	  public void beforeMethod() {
		
		  dr=Library.Launch_browser("CHROME","https://www.phptravels.net/home");
		  
	  }
	 
	 @Test(priority=0)
	  public void Logindata() throws InterruptedException {
		  System.out.println("mohan");
		  FROMTO f=new FROMTO(dr);
		  f.FROMTOSelect();
		  
	  }
	 
	 @Test(priority=1)
	  public void Pricegetting() throws InterruptedException {
		  System.out.println("mohan1");
		  price f1=new price(dr);
		  int n=f1.getprice();
		  boolean b;
		  if(n>100&&n<250)
		  {
			  b=true;
			  System.out.println("mete rea");
			  Assert.assertTrue(b, "met the requirements");
		  }
		  else
		  {
			  b=false;
			  Assert.assertTrue(b, " dont met the requirements");
		  }
		  
	  }
 

}
