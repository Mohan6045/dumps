package Com.BaseClass;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShots {
	
	 WebDriver driver;
	
	public ScreenShots(WebDriver driver)
	{
		this.driver =driver;
	}
	// function to take a screenshot
	public void ScreenShot(String FileName)
	{
		String	path="src\\test\\resources\\Screenshots\\";
		File f1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File f2 = new File(path+FileName);
		try {
			FileUtils.copyFile(f1, f2);
			
		} catch (IOException e) {
			
		}
	}
}

