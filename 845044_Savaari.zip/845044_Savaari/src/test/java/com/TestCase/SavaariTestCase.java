package com.TestCase;

import org.testng.annotations.Test;

import com.Pages.ResultPage;
import com.Pages.SavaariOneWayTrip;

import Com.BaseClass.ScreenShots;
import Com.BaseClass.WrapperClass;
import Com.ExcelUtility.ReadExcel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class SavaariTestCase extends WrapperClass {

	WebDriver driver;
	//SavaariOneWayTrip Class Instantiation
	SavaariOneWayTrip savaaritrip ;
	//ScreenShots Class Instantiation
	ScreenShots screenshot;
	//ReadExcel Class Instantiation
	ReadExcel readvalue;
	//ResultPage Class Instantiation
	ResultPage results;

	//Launching Browser from WrapperClass
	@BeforeClass
	@Parameters("browser")
	public void launchApplication(String browser) throws InterruptedException {

		driver = launchBrowser(browser,"https://www.savaari.com");
	}
	@Test
	public void testCase() throws InterruptedException {

		//Object creation for readexcel class
		readvalue =  new ReadExcel();
		//Reading data from excel for from location
		String fromcity=readvalue.getData("src\\test\\resources\\Testdata\\SavaariData.xlsx","Sheet1", 1, 0);
		//Reading data from excel for to location
		String tocity= readvalue.getData("src\\test\\resources\\Testdata\\SavaariData.xlsx","Sheet1", 1, 1);
		//Object creation for SavaariOneWayTrip
		savaaritrip  = new SavaariOneWayTrip(driver);
		//Object creation for ResultPage
		results = new ResultPage(driver);
		//Object creation for ScreenShots Class
		screenshot =new ScreenShots(driver);
		//calling oneWaytrip method
		savaaritrip.oneWaytrip();
		//calling fromLocation method and passing data
		savaaritrip.fromLocation(fromcity);
		//calling toLocation method and passing data
		savaaritrip.toLocation(tocity);
		//calling selectDate method
		savaaritrip.selectDate();
		//calling selectTime method
		savaaritrip.selectTime();
		//calling selectCar method
		savaaritrip.selectCar();
		//calling secondCarName method and assigning returned data to carName variable
		String carname=results.secondCarName();
		//printing returned value in console
		System.out.println("second car name is  "+carname );
		Thread.sleep(2000);
		//calling ScreenShot method with file name
		screenshot.ScreenShot("result.png");  

	}
	//Cloasing the opened browser
	@AfterClass
	public void closeApplication() {
		closeBrowser();
	}
}
