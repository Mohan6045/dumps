package Com.ExcelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	
	// reading data from excel (String)
			public  String getData(String filename,String Sheet,int r,int c)  
			{
				String s=null;
				try {
					File f=new File(filename);               // gets the filename
					FileInputStream fin= new FileInputStream(f);   // creating object for FileInputStream
					XSSFWorkbook wb=new XSSFWorkbook(fin);            // creating object for XSSFWorkbook
					XSSFSheet sh= wb.getSheet(Sheet); 				//creating object for getSheet
					XSSFRow row=sh.getRow(r);                      // gets row number and stored in row object
					XSSFCell cell =row.getCell(c);     				// gets cell number and stored in cell object					          
					s=cell.getStringCellValue();        // retrives data from cell
					} catch (FileNotFoundException e) {
				
						e.printStackTrace();
					} catch (IOException e) {
				
						e.printStackTrace();
					}
				return s;
			}

}
